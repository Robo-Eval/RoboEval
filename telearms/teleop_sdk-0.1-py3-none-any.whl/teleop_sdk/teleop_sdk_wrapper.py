import ctypes
import os

LIBAGORA_RTC_SDK_PATH = os.path.join(os.path.dirname(__file__), "lib", "libagora-rtc-sdk.so")
LIBTELEOP_SDK_PATH = os.path.join(os.path.dirname(__file__), "lib", "libteleop_sdk.so")

libagora_rtc_sdk = ctypes.CDLL(LIBAGORA_RTC_SDK_PATH, mode=ctypes.RTLD_GLOBAL)
libteleop_sdk = ctypes.CDLL(LIBTELEOP_SDK_PATH)

OnMessageReceivedType = ctypes.CFUNCTYPE(None, ctypes.c_char_p)
OnEventCallbackType = ctypes.CFUNCTYPE(None, ctypes.c_char_p, ctypes.c_void_p)
OnAudioDataReceivedType = ctypes.CFUNCTYPE(None, ctypes.POINTER(ctypes.c_uint8), ctypes.c_size_t, ctypes.c_uint32)

class TeleopEventHandler(ctypes.Structure):
    _fields_ = [
        ('on_message_received', OnMessageReceivedType),
        ('on_audio_data_received', OnAudioDataReceivedType),
        ('on_event_callback', OnEventCallbackType),
    ]

class TeleopConfig(ctypes.Structure):
    _fields_ = [
        ('project', ctypes.c_char_p),
        ('secret_id', ctypes.c_char_p),
        ('secret_key', ctypes.c_char_p),
        ('room_id', ctypes.c_char_p),
        ('user_id', ctypes.c_int),
        ('enable_video', ctypes.c_int),
        ('enable_audio', ctypes.c_int),
        ('enable_ctrl', ctypes.c_int),
        ('record', ctypes.c_int),
        ('subscribe_audio', ctypes.c_bool),
        ('test_uid', ctypes.c_char_p),
        ('ca_path', ctypes.c_char_p),
        ('cert_path', ctypes.c_char_p),
        ('key_path', ctypes.c_char_p),
        ('client_id', ctypes.c_char_p),
    ]


libteleop_sdk.teleop_sdk_init.argtypes = [ctypes.POINTER(TeleopConfig), ctypes.POINTER(TeleopEventHandler)]
libteleop_sdk.teleop_sdk_init.restype = None

libteleop_sdk.teleop_sdk_connect.argtypes = []
libteleop_sdk.teleop_sdk_connect.restype = None

libteleop_sdk.teleop_sdk_disconnect.argtypes = []
libteleop_sdk.teleop_sdk_disconnect.restype = None

libteleop_sdk.teleop_sdk_deinit.argtypes = []
libteleop_sdk.teleop_sdk_deinit.restype = None

libteleop_sdk.teleop_sdk_send_message.argtypes = [ctypes.c_char_p, ctypes.c_int, ctypes.c_char_p]
libteleop_sdk.teleop_sdk_send_message.restype = None

libteleop_sdk.teleop_sdk_send_video_data.argtypes = [ctypes.POINTER(ctypes.c_ubyte), ctypes.c_int, ctypes.c_int]
libteleop_sdk.teleop_sdk_send_video_data.restype = None

libteleop_sdk.teleop_sdk_add_token.argtypes = [ctypes.c_char_p, ctypes.c_int, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p]
libteleop_sdk.teleop_sdk_add_token.restype = None

_global_message_received_cb = None
_global_event_cb = None
_initialized = False

def init(secret_id="", secret_key="", room_id="", user_id=0, message_received_callback=None, on_event_callback=None, enable_video=0, enable_ctrl=1):
    global _global_message_received_cb, _global_event_cb, _initialized
    _global_message_received_cb = OnMessageReceivedType(message_received_callback)
    _global_event_cb = OnEventCallbackType(on_event_callback)

    config = TeleopConfig(
        project=b"teleop_python_sdk",
        secret_id=secret_id.encode(),
        secret_key=secret_key.encode(),
        room_id=room_id.encode(),
        user_id=int(user_id),
        enable_video=enable_video,
        enable_audio=0,
        enable_ctrl=enable_ctrl,
        record=0,
        subscribe_audio=False,
        test_uid=b"",
        ca_path=b"",
        cert_path=b"",
        key_path=b"",
        client_id=b"",
    )

    handler = TeleopEventHandler(
        on_message_received=_global_message_received_cb,
        on_audio_data_received=OnAudioDataReceivedType(0),
        on_event_callback=_global_event_cb
    )
    libteleop_sdk.teleop_sdk_init(ctypes.byref(config), ctypes.byref(handler))
    _initialized = True

def deinit():
    global _global_message_received_cb, _global_event_cb, _initialized
    if not _initialized:
        return
    libteleop_sdk.teleop_sdk_deinit()
    _global_message_received_cb = None
    _global_event_cb = None
    _initialized = False

def set_token(channel, rtc_uid, rtc_token, rtm_uid, rtm_token):
    libteleop_sdk.teleop_sdk_add_token(channel.encode(), int(rtc_uid), rtc_token.encode(), rtm_uid.encode(), rtm_token.encode())

def connect():
    libteleop_sdk.teleop_sdk_connect()

def disconnect():
    libteleop_sdk.teleop_sdk_disconnect()

def send_video(data):
    data_bytes = data.tobytes() if hasattr(data, 'tobytes') else data
    data_len = len(data_bytes)

    data_array = (ctypes.c_ubyte * data_len).from_buffer_copy(data_bytes)
    data_ptr = ctypes.cast(data_array, ctypes.POINTER(ctypes.c_ubyte))
    libteleop_sdk.teleop_sdk_send_video_data(data_ptr, data_len, 0)

def send_message(message, uid):
    libteleop_sdk.teleop_sdk_send_message(message.encode(), len(message), uid.encode())
